import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'

export default function ProfilePage(){
  const { profile, email, refresh } = useAuth() as any
  const [displayName,setDisplayName]=useState('')
  const [username,setUsername]=useState('')
  const [phone,setPhone]=useState('')
  const [newPass,setNewPass]=useState('')
  const [confirmPass,setConfirmPass]=useState('')
  const [msg,setMsg]=useState<string|null>(null)
  const [uStatus,setUStatus]=useState<'idle'|'checking'|'ok'|'taken'>('idle')
  const [busy,setBusy]=useState(false)

  useEffect(()=>{
    if(profile){
      setDisplayName(profile.display_name || '')
      setUsername(profile.username || '')
      setPhone(profile.phone || '')
    }
  },[profile])

  // live username check (if changed)
  useEffect(()=>{
    const name = username.trim()
    if(!name || name===profile?.username){ setUStatus('idle'); return }
    setUStatus('checking')
    const t = window.setTimeout(async()=>{
      const { data, error } = await supabase.rpc('is_username_available',{ p_username: name } as any)
      if(error){
        const { data: row } = await supabase.from('profiles').select('id').eq('username',name).maybeSingle()
        setUStatus(row ? 'taken' : 'ok')
      } else setUStatus(data ? 'ok' : 'taken')
    },450)
    return ()=> window.clearTimeout(t)
  },[username, profile?.username])

  const saveProfile = async(e:React.FormEvent)=>{
    e.preventDefault(); setMsg(null)
    if(uStatus==='taken'){ setMsg('این نام کاربری قبلاً گرفته شده'); return }
    const ph = phone.trim()
    if(ph && !/^[0-9 +()-]{7,20}$/.test(ph)){ setMsg('شماره موبایل معتبر نیست'); return }
    const dn = displayName.trim()
    const un = username.trim()
    if(un && un.length<3){ setMsg('نام کاربری حداقل ۳ کاراکتر'); return }
    if(un && !/^[a-zA-Z0-9._-]+$/.test(un)){ setMsg('نام کاربری فقط حروف/عدد/._-'); return }
    setBusy(true)
    const payload:any = {}
    if(dn !== (profile?.display_name||'')) payload.display_name = dn || null
    if(un !== (profile?.username||'')) payload.username = un || null
    // phone even if empty -> null
    const curPhone = profile?.phone || ''
    if(ph !== curPhone) payload.phone = ph || null
    if(Object.keys(payload).length===0){ setMsg('تغییری اعمال نشد'); setBusy(false); return }
    const { error } = await supabase.from('profiles').update(payload).eq('id', profile.id)
    if(error) setMsg(error.message.includes('duplicate') || error.message.includes('unique') ? 'این نام کاربری قبلاً گرفته شده' : error.message)
    else { setMsg('✅ پروفایل ذخیره شد'); await refresh() }
    setBusy(false)
  }

  const changePass = async(e:React.FormEvent)=>{
    e.preventDefault(); setMsg(null)
    if(newPass.length<6){ setMsg('رمز جدید حداقل ۶ کاراکتر'); return }
    if(newPass!==confirmPass){ setMsg('تکرار رمز همخوانی ندارد'); return }
    setBusy(true)
    const { error } = await supabase.auth.updateUser({ password: newPass })
    if(error) setMsg(error.message)
    else { setMsg('✅ رمز عبور تغییر کرد'); setNewPass(''); setConfirmPass('') }
    setBusy(false)
  }

  const uBorder = uStatus==='taken' ? 'rgba(255,60,90,.6)' : uStatus==='ok' ? 'rgba(0,229,160,.5)' : undefined
  const uHint = uStatus==='taken' ? '❌ گرفته شده' : uStatus==='ok' ? '✅ آزاد است' : uStatus==='checking' ? 'در حال بررسی…' : null

  return (
    <div className="container" style={{maxWidth:560, padding:'24px 14px 28px'}}>
      <h2 style={{fontWeight:900,fontSize:22}}>حساب کاربری</h2>
      <p style={{color:'var(--muted)',fontSize:12,marginTop:4}}>نام و موبایل اختیاری — هر زمان قابل تغییر.</p>
      {email && <div style={{marginTop:10,padding:'10px 12px',borderRadius:12,background:'var(--surface)',border:'1px solid var(--line)',fontSize:12}}>ایمیل: <b dir="ltr">{email}</b></div>}
      {msg && <div style={{marginTop:10,padding:'10px 12px',borderRadius:12,fontSize:13,wordBreak:'break-word',background: msg.startsWith('✅')?'rgba(0,229,160,.12)':'rgba(255,60,90,.12)',border:`1px solid ${msg.startsWith('✅')?'rgba(0,229,160,.3)':'rgba(255,60,90,.3)'}`}}>{msg}</div>}

      <form onSubmit={saveProfile} className="card" style={{marginTop:14,padding:16,display:'grid',gap:10}}>
        <h3 style={{fontWeight:800,fontSize:14}}>پروفایل</h3>
        <label style={{display:'grid',gap:6}}>
          <span style={{fontSize:11,color:'var(--muted)',fontWeight:700}}>نام نمایشی (اختیاری)</span>
          <input className="input" placeholder="مثلاً علی حسینی" value={displayName} onChange={e=>setDisplayName(e.target.value)} />
        </label>
        <label style={{display:'grid',gap:6}}>
          <span style={{fontSize:11,color:'var(--muted)',fontWeight:700}}>نام کاربری</span>
          <input className="input" placeholder="username" value={username} onChange={e=>setUsername(e.target.value)} dir="ltr" style={uBorder?{borderColor:uBorder}:undefined} />
          {uHint && <span style={{fontSize:11,color: uStatus==='taken'?'#ff6b7a': uStatus==='ok'?'var(--accent)':'var(--muted)'}}>{uHint}</span>}
        </label>
        <label style={{display:'grid',gap:6}}>
          <span style={{fontSize:11,color:'var(--muted)',fontWeight:700}}>شماره موبایل (اختیاری)</span>
          <input className="input" placeholder="0912 345 6789" value={phone} onChange={e=>setPhone(e.target.value)} dir="ltr" inputMode="tel" autoComplete="tel" />
        </label>
        <button className="btn btn-primary" disabled={busy || uStatus==='taken'} style={{minHeight:42}}>ذخیره پروفایل</button>
      </form>

      <form onSubmit={changePass} className="card" style={{marginTop:14,padding:16,display:'grid',gap:10}}>
        <h3 style={{fontWeight:800,fontSize:14}}>تغییر رمز عبور</h3>
        <input className="input" type="password" placeholder="رمز جدید (≥۶)" value={newPass} onChange={e=>setNewPass(e.target.value)} dir="ltr" autoComplete="new-password" />
        <input className="input" type="password" placeholder="تکرار رمز جدید" value={confirmPass} onChange={e=>setConfirmPass(e.target.value)} dir="ltr" autoComplete="new-password" />
        <button className="btn btn-ghost" disabled={busy} style={{minHeight:42}}>تغییر رمز</button>
      </form>
    </div>
  )
}
