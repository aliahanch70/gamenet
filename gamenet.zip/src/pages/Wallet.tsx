import { useEffect, useState } from 'react'
import { supabase, type Withdrawal } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'

type Tx = { id:string; amount:number; type:string; note:string|null; created_at:string }
const TX_PAGE_SIZE = 20
const WD_PAGE_SIZE = 10

export default function Wallet(){
  const { profile, refresh, userId, updateBalance } = useAuth() as any
  const [txs,setTxs]=useState<Tx[]>([])
  const [wds,setWds]=useState<Withdrawal[]>([])
  const [wdAmount,setWdAmount]=useState('')
  const [wdAccount,setWdAccount]=useState('')
  const [wdBusy,setWdBusy]=useState(false)
  const [msg,setMsg]=useState<string|null>(null)
  const [txFilter,setTxFilter]=useState<'all'|'charge'|'bet'|'win'|'refund'|'withdrawal'>('all')
  const [txLoading,setTxLoading]=useState(true)
  const [txPage,setTxPage]=useState(0)
  const [txHasMore,setTxHasMore]=useState(false)
  const [wdPage,setWdPage]=useState(0)
  const [wdHasMore,setWdHasMore]=useState(false)

  const loadTxs = async(page:number)=>{
    if(!userId) return
    setTxLoading(true)
    const from=page*TX_PAGE_SIZE, to=from+TX_PAGE_SIZE-1
    const { data, count } = await (supabase.from('transactions') as any).select('id,amount,type,note,created_at',{count:'exact'}).eq('user_id', userId).order('created_at',{ascending:false}).range(from,to)
    setTxs((data as Tx[])||[])
    setTxHasMore(count!=null ? (from+TX_PAGE_SIZE < count) : ((data as any[])?.length===TX_PAGE_SIZE))
    setTxPage(page)
    setTxLoading(false)
  }
  const loadWds = async(page:number)=>{
    if(!userId) return
    const from=page*WD_PAGE_SIZE, to=from+WD_PAGE_SIZE-1
    const { data, count } = await (supabase.from('withdrawals') as any).select('id,amount,account,status,note,created_at,decided_at',{count:'exact'}).eq('user_id', userId).order('created_at',{ascending:false}).range(from,to)
    setWds((data as Withdrawal[])||[])
    setWdHasMore(count!=null ? (from+WD_PAGE_SIZE < count) : ((data as any[])?.length===WD_PAGE_SIZE))
    setWdPage(page)
  }
  const load = async()=>{
    await Promise.all([loadTxs(txPage), loadWds(wdPage)])
  }
  useEffect(()=>{ if(userId) load(); else setTxLoading(false) },[userId])

  const submitWd = async(e:React.FormEvent)=>{
    e.preventDefault(); setMsg(null)
    const amt = Number(String(wdAmount).replace(/[^0-9]/g,''))
    if(!amt || amt<10000){ setMsg('حداقل برداشت ۱۰٬۰۰۰ تومان'); return }
    if(!wdAccount.trim() || wdAccount.trim().length<6){ setMsg('شماره کارت/حساب را کامل وارد کنید'); return }
    setWdBusy(true)
    const { error } = await supabase.rpc('request_withdrawal',{ p_amount: amt, p_account: wdAccount.trim() })
    if(error) setMsg(error.message)
    else { setMsg('✅ درخواست ثبت شد — پس از تایید ادمین واریز می‌شود'); setWdAmount(''); setWdAccount(''); try{ updateBalance(-amt) }catch{}; await loadWds(0); await loadTxs(0); await refresh() }
    setWdBusy(false)
  }

  return (
    <div className="container" style={{maxWidth:760,padding:'20px 14px 28px'}}>
      <h2 style={{fontWeight:900,fontSize:22}}>کیف پول</h2>
      <div className="card" style={{padding:18,marginTop:14,background:'linear-gradient(135deg,#0f2a22,#162040)'}}>
        <div style={{color:'var(--muted)',fontSize:12}}>موجودی فعلی</div>
        <div style={{fontSize:'clamp(28px, 7vw, 36px)',fontWeight:900,marginTop:4,wordBreak:'break-all'}}>{profile ? profile.balance.toLocaleString('fa-IR') : '—'} <span style={{fontSize:14,fontWeight:600}}>تومان</span></div>
        <div style={{marginTop:12,display:'flex',gap:8,flexWrap:'wrap',alignItems:'center'}}>
          <button className="btn btn-ghost btn-sm" onClick={async()=>{ await refresh(); await loadTxs(0); await loadWds(0) }}>بروزرسانی</button>
          <span style={{fontSize:12,color:'var(--muted)'}}>شارژ توسط پشتیبانی انجام می‌شود.</span>
        </div>
      </div>

      <div className="card" style={{padding:14,marginTop:14}}>
        <h3 style={{fontWeight:800,fontSize:15}}>درخواست برداشت</h3>
        <p style={{fontSize:11,color:'var(--muted)',marginTop:4}}>مبلغ از کیف پول کسر و پس از تایید ادمین واریز می‌شود. در صورت رد، مبلغ برگشت می‌خورد.</p>
        {msg && <div style={{marginTop:10,padding:'10px 12px',borderRadius:10,fontSize:13,wordBreak:'break-word',background: msg.startsWith('✅')?'rgba(0,229,160,.12)':'rgba(255,60,90,.12)',border:`1px solid ${msg.startsWith('✅')?'rgba(0,229,160,.3)':'rgba(255,60,90,.3)'}`}}>{msg}</div>}
        <form onSubmit={submitWd} style={{display:'grid',gap:10,marginTop:12}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr auto',gap:8}}>
            <input className="input" placeholder="مبلغ (تومان) — حداقل ۱۰٬۰۰۰" value={wdAmount} onChange={e=>setWdAmount(e.target.value)} inputMode="numeric" dir="ltr"/>
            <button type="button" className="btn btn-ghost btn-sm" style={{minHeight:42,whiteSpace:'nowrap'}} onClick={()=>{ if(profile) setWdAmount(String(profile.balance)) }} disabled={!profile || profile.balance<=0}>برداشت همه</button>
          </div>
          <input className="input" placeholder="شماره کارت/شبای مقصد" value={wdAccount} onChange={e=>setWdAccount(e.target.value)} dir="ltr"/>
          <button className="btn btn-primary" disabled={wdBusy} style={{minHeight:42}}>{wdBusy?'…':'ثبت درخواست برداشت'}</button>
        </form>
      </div>

      {txLoading ? <div style={{marginTop:14,display:'grid',gap:8}}>{[0,1].map(i=> <div key={i} className="skeleton skeleton-row" />)}</div> : wds.length>0 && (
        <div style={{marginTop:14}}>
          <h3 style={{fontWeight:800,fontSize:15,marginBottom:8}}>درخواست‌های من</h3>
          <div style={{display:'grid',gap:8}}>
            {wds.map(w=>{
              const st = w.status==='pending' ? {label:'در انتظار',bg:'rgba(245,166,35,.14)',color:'#ffb84d'} : w.status==='approved' ? {label:'تایید شد ✅',bg:'rgba(0,229,160,.14)',color:'var(--accent)'} : {label:'رد شد',bg:'rgba(255,60,90,.12)',color:'#ff6b7a'}
              return (
                <div key={w.id} className="card" style={{padding:12,display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,flexWrap:'wrap'}}>
                  <div><div style={{fontWeight:800,fontSize:13}}>{Number(w.amount).toLocaleString('fa-IR')} ت <span style={{fontSize:11,color:'var(--muted)'}}>· {w.account}</span></div><div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>{new Date(w.created_at).toLocaleString('fa-IR')}</div>{w.note && <div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>{w.note}</div>}</div>
                  <span style={{fontSize:11,fontWeight:800,padding:'4px 10px',borderRadius:999,background:st.bg,color:st.color,whiteSpace:'nowrap'}}>{st.label}</span>
                </div>
              )
            })}
          </div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,marginTop:8}}>
            <span style={{fontSize:11,color:'var(--muted)'}}>صفحه {(wdPage+1).toLocaleString('fa-IR')}</span>
            <div style={{display:'flex',gap:6}}>
              <button className="btn btn-ghost btn-sm" disabled={wdPage===0} onClick={()=> loadWds(wdPage-1)} style={{borderRadius:999}}>قبلی</button>
              <button className="btn btn-ghost btn-sm" disabled={!wdHasMore} onClick={()=> loadWds(wdPage+1)} style={{borderRadius:999}}>بعدی</button>
            </div>
          </div>
        </div>
      )}

      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:8,marginTop:20}}>
        <h3 style={{fontWeight:800,fontSize:15}}>تراکنش‌ها {txs.length>0 && <span style={{fontWeight:600,color:'var(--muted)',fontSize:12}}>· {(txFilter==='all'?txs:txs.filter(x=> x.type===txFilter)).length}{txFilter!=='all'?` / ${txs.length}`:''}</span>}</h3>
        {txs.length>0 && (
          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
            {(['all','charge','bet','win','refund','withdrawal'] as const).map(k=>{
              const label = k==='all'?'همه':k==='charge'?'شارژ':k==='bet'?'شرط':k==='win'?'برد':k==='refund'?'برگشت':'برداشت'
              const cnt = k==='all'? txs.length : txs.filter(x=> x.type===k).length
              return <button key={k} onClick={()=> setTxFilter(k)} className={txFilter===k ? 'btn btn-primary btn-sm' : 'btn btn-ghost btn-sm'} style={{borderRadius:999, minHeight:28, fontSize:12, padding:'4px 10px'}}>{label} ({cnt})</button>
            })}
          </div>
        )}
      </div>
      {txLoading ? <div style={{marginTop:10,display:'grid',gap:8}}>{[0,1,2,3].map(i=> <div key={i} className="skeleton skeleton-row" />)}</div> : (() => { const filtered = txFilter==='all'? txs : txs.filter(x=> x.type===txFilter); return filtered.length===0 ? <div style={{color:'var(--muted)',fontSize:13,marginTop:10}}>{txs.length===0?'تراکنشی نیست.':'در این فیلتر تراکنشی نیست.'}</div> :
        <div className="card" style={{overflow:'hidden'}}>
          <div className="table-wrap" style={{margin:0,padding:0}}>
          <table className="table">
            <thead><tr><th>نوع</th><th>مبلغ</th><th>توضیح</th><th>تاریخ</th></tr></thead>
            <tbody>{filtered.map(t=>(
              <tr key={t.id}>
                <td><span className="badge" style={{fontSize:11}}>{t.type==='charge'?'شارژ':t.type==='bet'?'شرط':t.type==='win'?'برد':t.type==='withdrawal'?'برداشت':t.type==='refund'?'برگشت':'—'}</span></td>
                <td style={{color: t.amount>=0 ? 'var(--accent)' : '#ff6b7a',fontWeight:700, direction:'ltr',textAlign:'right',whiteSpace:'nowrap'}}>
                  {t.amount>0?'+':''}{Number(t.amount).toLocaleString('fa-IR')}
                </td>
                <td style={{fontSize:12,color:'var(--muted)',maxWidth:160,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{t.note||'—'}</td>
                <td style={{fontSize:11,color:'var(--muted)',whiteSpace:'nowrap'}}>{new Date(t.created_at).toLocaleString('fa-IR')}</td>
              </tr>
            ))}</tbody>
          </table>
          </div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:8,padding:'10px 12px',borderTop:'1px solid var(--line)'}}>
            <span style={{fontSize:11,color:'var(--muted)'}}>صفحه {(txPage+1).toLocaleString('fa-IR')}</span>
            <div style={{display:'flex',gap:6}}>
              <button className="btn btn-ghost btn-sm" disabled={txPage===0} onClick={()=> loadTxs(txPage-1)} style={{borderRadius:999}}>قبلی</button>
              <button className="btn btn-ghost btn-sm" disabled={!txHasMore} onClick={()=> loadTxs(txPage+1)} style={{borderRadius:999}}>بعدی</button>
            </div>
          </div>
        </div>
      })()}
    </div>
  )
}
